package org.example.constants;

public class Env {
    public static final String BASE_URL="https://cloud.google.com/";
    public static final String CALCUALTOR_PAGE_URL="https://cloud.google.com/products/calculator";
    public static final String DEV_ENV="C:\\Users\\Srijit_Chowdhury\\IdeaProjects\\HurtMePlenty\\src\\test\\resources\\dev.properties";
    public static final String QA_ENV="C:\\Users\\Srijit_Chowdhury\\IdeaProjects\\HurtMePlenty\\src\\test\\resources\\qa.properties";

    //public static final String USER_NAME="testdata.user.name";
}
