package org.example.model;

public class Calculator {
    private String NumberOfInstancesField;
    //    private String selectOS;
//    private String machineSeries;
    private String selectMachineType;
//    private String NumberGPUs;
//    private String GPUtype;
//    private String LocalSSD;
//    private String datacenterLocation;
    public String getNumberOfInstancesField() {
        return NumberOfInstancesField;
    }

    public void setNumberOfInstancesField(String numberOfInstancesField) {
        NumberOfInstancesField = numberOfInstancesField;
    }

//    public String getSelectOS() {
//        return selectOS;
//    }
//
//    public void setSelectOS(String selectOS) {
//        this.selectOS = selectOS;
//    }
//
//    public String getMachineSeries() {
//        return machineSeries;
//    }
//
//    public void setMachineSeries(String machineSeries) {
//        this.machineSeries = machineSeries;
//    }
//
    public String getSelectMachineType() {
        return selectMachineType;
    }

    public void setSelectMachineType(String selectMachineType) {
        this.selectMachineType = selectMachineType;
    }
//
//    public String getNumberGPUs() {
//        return NumberGPUs;
//    }
//
//    public void setNumberGPUs(String numberGPUs) {
//        NumberGPUs = numberGPUs;
//    }
//
//    public String getGPUtype() {
//        return GPUtype;
//    }
//
//    public void setGPUtype(String GPUtype) {
//        this.GPUtype = GPUtype;
//    }
//
//    public String getLocalSSD() {
//        return LocalSSD;
//    }
//
//    public void setLocalSSD(String localSSD) {
//        LocalSSD = localSSD;
//    }
//
//    public String getDatacenterLocation() {
//        return datacenterLocation;
//    }
//
//    public void setDatacenterLocation(String datacenterLocation) {
//        this.datacenterLocation = datacenterLocation;
//    }

}
