package org.example.invoker;

import org.openqa.selenium.WebDriver;

public interface WebDriverInvoker {
    WebDriver invokeWebDriver();
}
